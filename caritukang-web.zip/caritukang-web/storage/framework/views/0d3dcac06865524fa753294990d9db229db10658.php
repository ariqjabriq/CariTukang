<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Daftar Mitra</h1>
    <table border="1" cellspacing="0" cellpadding="3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Lengkap</th>
                <th>Alamat</th>
                <th>Nomor Hp</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($mitra->id); ?></td>
                <td><?php echo e($mitra->nama); ?></td>
                <td><?php echo e($mitra->alamat); ?></td>
                <td><?php echo e($mitra->nomorhp); ?></td>
                <td><?php echo e($mitra->email); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\caritukang-main\resources\views/download/mitrapdf.blade.php ENDPATH**/ ?>