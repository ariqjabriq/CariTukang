<!-- base template -->

<!-- end base -->
<?php $__env->startSection('title','Create Administrator'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="box shadow p-3 mb-5 bg-body rounded">

        <div class="row">
            <div class="col">
                <h3>Create Administrator</h3>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <form method="post" action="<?php echo e(route('administrators.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan Nama Lengkap">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="validationServerUsernameFeedback" class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <input type="text" class="form-control " id="alamat" name="alamat"  value="<?php echo e(old('alamat')); ?>" placeholder="Masukkan Alamat">
                    </div>
                    <div class="mb-3">
                        <label for="nomorhp" class="form-label">Nomor Handphone</label>
                        <input type="text" class="form-control" id="nomorhp" name="nomorhp" value="<?php echo e(old('nomorhp')); ?>" placeholder="Masukkan Nomor Handphone">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Email</label>
                        <input type="email" class="form-control" id="email" name="email"  value="<?php echo e(old('email')); ?>" placeholder="Masukkan Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="validationServerUsernameFeedback" class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Roles</label>
                        <select class="form-select" aria-label="Default select example" id="role" name="role">
                            <option selected>Select Roles</option>
                            <option value="Super Administrator">Super Administrator</option>
                            <option value="Administrator">Administrator</option>
                        </select>
                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="validationServerUsernameFeedback" class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    </div>
                    <button class="btn btn-primary">Create</button>
                    
                </form>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caritukang-main\resources\views/adminPage/createAdminPage.blade.php ENDPATH**/ ?>