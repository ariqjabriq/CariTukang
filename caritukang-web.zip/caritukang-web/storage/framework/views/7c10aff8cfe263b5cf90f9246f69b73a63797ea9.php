<!-- base template -->

<!-- end base -->
<?php $__env->startSection('title','Create Report'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="box shadow p-3 mb-5 bg-body rounded">
        <div class="row">
            <div class="col">
                <h3>Create Report</h3>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <form method="post" action="<?php echo e(route('reports.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="judul_laporan" class="form-label">Judul</label>
                        <input type="text" class="form-control " id="judul_laporan" name="judul_laporan"  value="<?php echo e(old('judul_laporan')); ?>" placeholder="Masukkan Judul Laporan">
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">Kategori</label>
                        <input type="text" class="form-control" id="category" name="category" placeholder="Masukkan Kategori" value="<?php echo e(old('category')); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="description" name="description" rows="5" placeholder="Masukkan Deskripsi Laporan"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Tanggal</label>
                        <input type="date" class="form-control date" id="date" name="date" width="10">
                    </div>
                    <button class="btn btn-primary">Create</button>
                    
                </form>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caritukang-main\resources\views/reportPage/createReportPage.blade.php ENDPATH**/ ?>